## Software Testing & QA | Assignment 2 ##
### [Thomas George](http://www.thethomasgeorge.com) | twg62 | 1/28/2020 ###
### [Click here to run the application](http://www.thethomasgeorge.com/Assignment2)
#### [Assignment Information](assignment.pdf) ####
#### [Link to Google Doc](https://docs.google.com/document/d/18wDgj3eSvK3TTnEbbyGzp6SeyseohhlrjuHxKXJ1uWg/edit?usp=sharing) ####


### Languages Used: ###
- HTML5
- [BootStrap 4.0](https://getbootstrap.com/docs/4.0/getting-started/introduction/)
- CSS3
- JavaScript
- [jQuery 3.4.1](https://www.nuget.org/packages/jQuery)

